package tcking.github.com.giraffeplayer2;

/**
 * Created by tcking on 2017
 */

public interface ScalableDisplay {

    void setAspectRatio(int ratio);
    void setVideoSize(int videoWidth, int videoHeight);
}
