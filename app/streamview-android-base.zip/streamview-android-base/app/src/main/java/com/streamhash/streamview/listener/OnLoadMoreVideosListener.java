package com.streamhash.streamview.listener;


public interface OnLoadMoreVideosListener {
    void onLoadMore(int skip);
}
