package com.streamhash.streamview.util;

public class Fragments {
    public static final String[]   HOME_FRAGMENTS = new String[]{
            "home",
            "search",
            "categories",
            "wishlist",
            "settings",
            "series",
            "flims",
            "kids"
    };
}
